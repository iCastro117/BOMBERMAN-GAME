/**
 * 
 */
/**
 * 
 */
module bomberman_3 {
	requires java.desktop;
}