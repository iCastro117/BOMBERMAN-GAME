package co.edu.konradlorenz.model;

public interface Movible {
	boolean mover(int dx, int dy);

}
